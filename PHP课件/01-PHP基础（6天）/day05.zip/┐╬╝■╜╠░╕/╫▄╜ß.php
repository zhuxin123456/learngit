<?php
系统常用的函数
	输出函数：print_r(),var_dump()
	时间函数：date(),time(),strtotime()
	数学函数：max(),min(),rand(),mt_rand(),round(),ceil(),floor(),
	有关函数的函数:function_exists(),func_get_arg(),func_get_args(),func_num_args()
	设置php.ini的配置文件信息：ini_set('配置项',配置值)

字符串
	PHP单引号，和双引号能识别的转义符：单引号中能够识别\’，而双引号中就不能识别\’

字符串函数
	strlen(),mb_strlen(),implode(), explode(), str_split(),trim(), ltrim(), rtrim(),substr(),
	strstr(),strtolower(), strtoupper(), ucfirst(),strpos(), strrpos(),str_replace(),
	str_repeat(), str_shuffle()
数组
	第一数组的三种方式：$arr=array(1,2,3); $arr=[1,2,3]; $arr[]=1,$arr[]=2
	数组根据下标可分为：索引数组，关联数组，混合数组

foreach循环
	语法形式:foreach(数组变量 as [$key]=>$value){循环体}

each函数的作用，list结构的使用



