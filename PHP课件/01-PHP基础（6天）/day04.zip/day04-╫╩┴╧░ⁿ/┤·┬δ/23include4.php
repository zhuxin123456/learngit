<table>
	<tr>
		<td><?php echo $a;?></td>
		<td><?php echo PI;?></td>
	</tr>
</table>