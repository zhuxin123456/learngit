<?php

	//定义数据

	$a = 10;
	const PI = 3.14;


	//包含文件：为了显示以上数据
	include_once 'include4.php';