<?php

	//加载father下面的father.php

	include 'father/father.php';