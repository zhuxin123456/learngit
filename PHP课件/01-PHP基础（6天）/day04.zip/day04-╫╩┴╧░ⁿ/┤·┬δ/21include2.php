<?php

	//包含文件：使用数据


	//包含文件
	include 'include1.php';	//包含当前文件include2.php所在文件夹下的include1.php

	echo $a,PI;


	//再次加载
	//include 'include1.php';

	//include_once
	//include_once 'include1.php';