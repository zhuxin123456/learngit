<?php

	//函数


	//调用函数
	display();


	//定义函数
	function display(){
		//函数体
		echo 'hello world';		//没有返回值
	}


	//调用函数
	//display();