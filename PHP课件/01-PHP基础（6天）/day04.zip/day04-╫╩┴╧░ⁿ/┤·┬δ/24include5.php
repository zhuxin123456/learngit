<?php

	//require和include的区别


	//include包含文件
	//include 'a.php';

	//require包含文件
	require 'a.php';


	echo 'hello world';