<?php


	echo 'father';
	//包含son目录下的son.php

	include 'son/son.php';