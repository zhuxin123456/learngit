<?php


	//包含include.php
	include_once 'include.php';