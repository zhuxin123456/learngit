<?php

	//定义数据

	$son = 'SON';

	echo $son,'<br/>';