<?php

	//包含有return关键字的文件


	$res = include_once 'function3.php';
	var_dump($res);