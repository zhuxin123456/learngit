<?php

	//PHP文件加载路径

	//相对路径加载
	//include_once 'include1.php';	//默认当前文件本身

	//include_once './include1.php';	

	//复杂相对路径
	//include_once '../htdocs/include1.php';



	//绝对路径
	include_once 'E:/server/apache/htdocs/include1.php';

	echo $a;
