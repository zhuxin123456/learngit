<?php

	//文件嵌套包含


	//包含include3.php//文件本身包含了include4.php
	include 'include3.php';