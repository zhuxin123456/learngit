<html>

<body>
	<b>
		<?php
			//脚本标记
			echo 'hello world';
		?>
	</b>
</body>
</html>