<?php

	//可变变量

	//定义两个变量
	$a = 'b';
	$b = 'bb';

	echo $$a;