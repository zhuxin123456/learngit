<html>

<body>
	<b>
		<script language="php">
			//脚本标记
			echo 'hello world';
		</script>
	</b>
</body>
</html>