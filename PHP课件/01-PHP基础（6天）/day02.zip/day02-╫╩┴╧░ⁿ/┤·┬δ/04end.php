<?php
	
	//语句结束符的使用

	echo 'hello world';
	echo 'hello world';







