<?php


$arr = array(1,4,2,9,7,5,8);
